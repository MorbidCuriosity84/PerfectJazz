#pragma once
#include <ecm.h>

class Background {
public:
	static void createBackground(Scene* _scene);
};
